﻿using System;

namespace C7
{
    class Program
    {
        static void Main(string[] args)
        {
            int countV = 0 ,countC=0;
            Console.WriteLine("Enter sequence");
            while (true)
            {
                var keyInfo = Console.ReadKey();
                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
                if (!char.IsLetter(letter)) break;
                if (letter == 'A' || letter == 'E' || letter == 'I' || letter == 'O' || letter == 'U')
                {
                    countV++;
                }
                else

                {
                    countC++;
                }

            }
            Console.WriteLine();
            Console.WriteLine(countV + "," +countC);
        }
    }
}
