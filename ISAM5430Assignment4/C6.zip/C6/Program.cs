﻿using System;

namespace C6
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            Console.WriteLine("Enter sequence");
            while (true)
            {
                var keyInfo = Console.ReadKey();
                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
                if (!char.IsLetter(letter)) break;
                //int num = Convert.ToInt32(letter);                                                     
                        count++;
                
            }
            Console.WriteLine();
            Console.WriteLine(count + "");
        }
    }
}
