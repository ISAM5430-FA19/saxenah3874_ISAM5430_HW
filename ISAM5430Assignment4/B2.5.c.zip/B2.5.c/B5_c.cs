﻿using static System.Console;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2_5
{
    class Program
    {
        static void Main(string[] args)
        {
            

            
            WriteLine("\n\nMiddle letter is a vowel and must contain unique characters");
            for (char a = 'A'; a <= 'H'; a++)
            {
                bool vowelA = a != 'A' && a != 'E';
                for (char b = 'A'; b <= 'H'; b++)
                {
                    bool vowelB = b == 'A' || b == 'E';
                    int vowels = (vowelA ? 1 : 0) + (vowelB ? 1 : 0);
                    if (vowels == 2)
                        WriteLine(a + "" + b);
                    for (char c = 'A'; c <= 'H'; c++)
                    {
                        bool vowelC = c != 'A' && c != 'E';
                        int vowelCCount = (vowelC ? 1 : 0) + vowels;
                        if (vowelCCount == 3 && a != c)
                            WriteLine(a + "" + b + "" + c);
                    }
                }

            }

            ReadLine();
            }
        }
    }